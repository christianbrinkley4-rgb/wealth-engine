#!/usr/bin/env python3
"""
Financial Statement Analyzer.

Reads an income statement and a balance sheet from CSV files, computes
standard financial ratios, runs year over year trend analysis, and flags
data problems. Written with only the Python standard library so it runs
anywhere with Python 3.8 or newer and needs no installs.

Usage:
    python3 analyzer.py
    python3 analyzer.py --income data/income_statement.csv --balance data/balance_sheet.csv
    python3 analyzer.py --out report.html
"""

import argparse
import csv
from pathlib import Path

COMPANY_NAME = "Blue Ridge Manufacturing Co."

# Columns we expect in each CSV file. The script computes the subtotal and
# total lines itself so the input stays close to raw bookkeeping data.
INCOME_COLUMNS = [
    "year", "revenue", "cogs", "operating_expenses",
    "interest_expense", "tax_expense",
]
BALANCE_COLUMNS = [
    "year", "cash", "accounts_receivable", "inventory", "ppe_net",
    "accounts_payable", "short_term_debt", "long_term_debt",
    "common_stock", "retained_earnings",
]

# Accounts that should never be negative. A negative here almost always
# means a data entry error or a misclassified line.
NON_NEGATIVE_FIELDS = [
    "revenue", "cogs", "operating_expenses", "interest_expense",
    "tax_expense", "cash", "accounts_receivable", "inventory",
    "ppe_net", "accounts_payable", "short_term_debt",
    "long_term_debt", "common_stock",
]

# A single year jump bigger than this (as a fraction) gets flagged as a
# possible typo or one time event worth verifying.
BIG_JUMP_THRESHOLD = 0.50

# The balance sheet must balance within this many dollars. Exact integer
# inputs should balance to the dollar, so the tolerance only absorbs
# rounding from real world statements.
BALANCE_TOLERANCE = 1.0


def load_csv(path):
    """Read a CSV file into a list of dicts with numeric values as floats."""
    rows = []
    with open(path, newline="") as f:
        reader = csv.DictReader(f)
        for line in reader:
            row = {}
            for key, value in line.items():
                value = value.strip()
                row[key] = float(value) if value else 0.0
            rows.append(row)
    rows.sort(key=lambda r: r["year"])
    return rows


def check_columns(rows, expected, label):
    """Make sure the CSV has every column the math below depends on."""
    if not rows:
        raise ValueError(f"{label} file is empty.")
    missing = [c for c in expected if c not in rows[0]]
    if missing:
        raise ValueError(f"{label} file is missing columns: {', '.join(missing)}")


def build_income(rows):
    """Derive the standard income statement lines from the raw inputs."""
    out = []
    for r in rows:
        gross_profit = r["revenue"] - r["cogs"]
        operating_income = gross_profit - r["operating_expenses"]
        pretax_income = operating_income - r["interest_expense"]
        net_income = pretax_income - r["tax_expense"]
        out.append({
            "year": r["year"],
            "revenue": r["revenue"],
            "cogs": r["cogs"],
            "gross_profit": gross_profit,
            "operating_income": operating_income,
            "interest_expense": r["interest_expense"],
            "tax_expense": r["tax_expense"],
            "net_income": net_income,
        })
    return out


def build_balance(rows):
    """Derive the balance sheet totals from the raw inputs."""
    out = []
    for r in rows:
        current_assets = r["cash"] + r["accounts_receivable"] + r["inventory"]
        total_assets = current_assets + r["ppe_net"]
        current_liabilities = r["accounts_payable"] + r["short_term_debt"]
        total_liabilities = current_liabilities + r["long_term_debt"]
        total_equity = r["common_stock"] + r["retained_earnings"]
        out.append({
            "year": r["year"],
            "cash": r["cash"],
            "receivables": r["accounts_receivable"],
            "inventory": r["inventory"],
            "current_assets": current_assets,
            "total_assets": total_assets,
            "current_liabilities": current_liabilities,
            "total_liabilities": total_liabilities,
            "total_equity": total_equity,
        })
    return out


def safe_div(numerator, denominator):
    """Divide, returning None instead of crashing on a zero denominator."""
    if denominator is None or denominator == 0:
        return None
    return numerator / denominator


def average(current, previous):
    """Average a balance sheet item across two year ends.

    Balance sheet items are snapshots, so ratios like ROE and turnover
    normally use the average of the beginning and ending balance. For the
    first year there is no prior year, so we fall back to the year end
    value and say so in the report.
    """
    if previous is None:
        return current
    return (current + previous) / 2.0


def compute_ratios(income, balance):
    """Compute one ratio dict per year, keyed by year."""
    ratios = {}
    for i, inc in enumerate(income):
        bal = balance[i]
        prev_bal = balance[i - 1] if i > 0 else None

        avg_equity = average(bal["total_equity"],
                             prev_bal["total_equity"] if prev_bal else None)
        avg_assets = average(bal["total_assets"],
                             prev_bal["total_assets"] if prev_bal else None)
        avg_receivables = average(bal["receivables"],
                                  prev_bal["receivables"] if prev_bal else None)
        avg_inventory = average(bal["inventory"],
                                prev_bal["inventory"] if prev_bal else None)

        ratios[inc["year"]] = {
            "current_ratio": safe_div(bal["current_assets"],
                                      bal["current_liabilities"]),
            "quick_ratio": safe_div(bal["current_assets"] - bal["inventory"],
                                    bal["current_liabilities"]),
            "gross_margin": safe_div(inc["gross_profit"], inc["revenue"]),
            "net_margin": safe_div(inc["net_income"], inc["revenue"]),
            "roe": safe_div(inc["net_income"], avg_equity),
            "roa": safe_div(inc["net_income"], avg_assets),
            "debt_to_equity": safe_div(bal["total_liabilities"],
                                       bal["total_equity"]),
            "debt_to_assets": safe_div(bal["total_liabilities"],
                                       bal["total_assets"]),
            "receivables_turnover": safe_div(inc["revenue"], avg_receivables),
            "inventory_turnover": safe_div(inc["cogs"], avg_inventory),
        }
    return ratios


def check_data_problems(income_rows, balance_rows, income, balance):
    """Look for values that suggest bad input rather than bad performance.

    Returns a list of human readable notes. An empty list means the data
    passed every check.
    """
    notes = []

    # 1. Negative values where they make no sense.
    for raw, label in ((income_rows, "income statement"),
                       (balance_rows, "balance sheet")):
        for r in raw:
            for field in NON_NEGATIVE_FIELDS:
                if field in r and r[field] < 0:
                    notes.append(
                        f"{int(r['year'])} {label}: {field} is "
                        f"negative (${r[field]:,.0f}). That usually means a "
                        f"data entry error."
                    )

    # 2. The accounting equation has to hold.
    for b in balance:
        diff = b["total_assets"] - (b["total_liabilities"] + b["total_equity"])
        if abs(diff) > BALANCE_TOLERANCE:
            notes.append(
                f"{int(b['year'])} balance sheet does not balance: assets "
                f"exceed liabilities plus equity by ${diff:,.0f}."
            )

    # 3. Huge single year jumps get flagged for a second look.
    watch = [
        ("revenue", income), ("cogs", income), ("net_income", income),
        ("cash", balance), ("receivables", balance), ("inventory", balance),
        ("total_assets", balance), ("total_liabilities", balance),
    ]
    for field, series in watch:
        for i in range(1, len(series)):
            prior = series[i - 1][field]
            current = series[i][field]
            if prior == 0:
                continue
            change = (current - prior) / abs(prior)
            if abs(change) > BIG_JUMP_THRESHOLD:
                direction = "up" if change > 0 else "down"
                notes.append(
                    f"{field} moved {direction} {abs(change):.0%} from "
                    f"{int(series[i - 1]['year'])} to {int(series[i]['year'])}. "
                    f"That is a big swing, worth verifying against the "
                    f"source documents."
                )
    return notes


def trend_flags(income, balance, ratios):
    """Turn year over year ratio moves into plain language flags."""
    flags = []
    for i in range(1, len(income)):
        year = int(income[i]["year"])
        prev_year = int(income[i - 1]["year"])
        r, p = ratios[income[i]["year"]], ratios[income[i - 1]["year"]]

        rev_growth = (income[i]["revenue"] - income[i - 1]["revenue"]) \
            / income[i - 1]["revenue"] if income[i - 1]["revenue"] else 0
        if rev_growth >= 0.20:
            flags.append(f"{year}: strong revenue growth of {rev_growth:.1%} "
                         f"over {prev_year}.")
        elif rev_growth < 0:
            flags.append(f"{year}: revenue declined {abs(rev_growth):.1%} "
                         f"from {prev_year}.")

        if r["gross_margin"] is not None and p["gross_margin"] is not None:
            move = r["gross_margin"] - p["gross_margin"]
            if move <= -0.02:
                pts = abs(move) * 100
                flags.append(f"{year}: margin compression. Gross margin fell "
                             f"from {p['gross_margin']:.1%} to "
                             f"{r['gross_margin']:.1%} (down {pts:.1f} "
                             f"points).")
            elif move >= 0.02:
                pts = move * 100
                flags.append(f"{year}: gross margin expanded to "
                             f"{r['gross_margin']:.1%} (up {pts:.1f} "
                             f"points).")

        if r["net_margin"] is not None and p["net_margin"] is not None:
            move = r["net_margin"] - p["net_margin"]
            if move <= -0.02:
                flags.append(f"{year}: net margin slipped from "
                             f"{p['net_margin']:.1%} to {r['net_margin']:.1%}. "
                             f"Profit is not keeping up with sales.")

        if r["current_ratio"] is not None:
            if r["current_ratio"] < 1.5:
                flags.append(f"{year}: current ratio is "
                             f"{r['current_ratio']:.2f}, below the 1.5 comfort "
                             f"level. Short term liquidity is getting tight.")
            elif (p["current_ratio"] is not None
                  and p["current_ratio"] - r["current_ratio"] >= 0.3):
                flags.append(f"{year}: liquidity is weakening. Current ratio "
                             f"fell from {p['current_ratio']:.2f} to "
                             f"{r['current_ratio']:.2f}.")

        if r["debt_to_equity"] is not None:
            if r["debt_to_equity"] > 1.5:
                flags.append(f"{year}: leverage is elevated at "
                             f"{r['debt_to_equity']:.2f}x debt to equity.")
            elif (p["debt_to_equity"] is not None
                  and r["debt_to_equity"] - p["debt_to_equity"] >= 0.2):
                flags.append(f"{year}: leverage is rising. Debt to equity "
                             f"moved from {p['debt_to_equity']:.2f} to "
                             f"{r['debt_to_equity']:.2f}.")

        for key, label in (("receivables_turnover", "receivables"),
                           ("inventory_turnover", "inventory")):
            if r[key] is not None and p[key] not in (None, 0):
                move = (r[key] - p[key]) / abs(p[key])
                if move <= -0.15:
                    thing = ("collections are slowing"
                             if key == "receivables_turnover"
                             else "inventory is building up")
                    flags.append(f"{year}: {label} turnover fell "
                                 f"{abs(move):.0%}, which suggests {thing}.")
    return flags


def fmt_ratio(value, as_percent=False):
    if value is None:
        return "n/a"
    if as_percent:
        return f"{value:.1%}"
    return f"{value:.2f}"


RATIO_ROWS = [
    ("current_ratio", "Current ratio", False),
    ("quick_ratio", "Quick ratio", False),
    ("gross_margin", "Gross margin", True),
    ("net_margin", "Net margin", True),
    ("roe", "Return on equity", True),
    ("roa", "Return on assets", True),
    ("debt_to_equity", "Debt to equity", False),
    ("debt_to_assets", "Debt to assets", False),
    ("receivables_turnover", "Receivables turnover", False),
    ("inventory_turnover", "Inventory turnover", False),
]


def build_text_report(income, balance, ratios, flags, problems):
    years = [int(i["year"]) for i in income]
    lines = []
    lines.append(COMPANY_NAME)
    lines.append("Financial Statement Analysis")
    lines.append(f"Years covered: {years[0]}-{years[-1]}")
    lines.append("")
    lines.append("KEY RATIOS")
    header = "Ratio".ljust(22) + "".join(str(y).rjust(12) for y in years)
    lines.append(header)
    lines.append("-" * len(header))
    for key, label, as_percent in RATIO_ROWS:
        row = label.ljust(22)
        for y in [i["year"] for i in income]:
            row += fmt_ratio(ratios[y][key], as_percent).rjust(12)
        lines.append(row)
    lines.append("")
    lines.append("NOTABLE TRENDS")
    if flags:
        for f in flags:
            lines.append(f"  * {f}")
    else:
        lines.append("  No notable trends. Ratios moved within normal ranges.")
    lines.append("")
    lines.append("DATA CHECKS")
    if problems:
        for note in problems:
            lines.append(f"  ! {note}")
    else:
        lines.append("  All checks passed: no negative balances where they "
                     "should not be,")
        lines.append("  the balance sheet balances every year, and no single "
                     "line item jumped")
        lines.append("  more than 50% year over year.")
    lines.append("")
    lines.append("Notes: ROE, ROA, and turnover ratios use average balances "
                 "where a prior year")
    lines.append("exists. For the first year they use year end balances.")
    return "\n".join(lines)


def build_csv_report(ratios):
    lines = ["ratio," + ",".join(str(int(y)) for y in ratios)]
    for key, label, as_percent in RATIO_ROWS:
        cells = []
        for y in ratios:
            v = ratios[y][key]
            cells.append(f"{v:.4%}" if (as_percent and v is not None)
                         else (f"{v:.4f}" if v is not None else "n/a"))
        lines.append(label + "," + ",".join(cells))
    return "\n".join(lines) + "\n"


def build_html_report(income, balance, ratios, flags, problems):
    years = [int(i["year"]) for i in income]
    rows = ""
    for key, label, as_percent in RATIO_ROWS:
        cells = "".join(
            f"<td>{fmt_ratio(ratios[y][key], as_percent)}</td>"
            for y in [i["year"] for i in income])
        rows += f"<tr><th>{label}</th>{cells}</tr>\n"
    flags_html = ("<li>" + "</li><li>".join(flags) + "</li>") if flags \
        else "<li>No notable trends. Ratios moved within normal ranges.</li>"
    problems_html = ("<li>" + "</li><li>".join(problems) + "</li>") \
        if problems else "<li>All data checks passed.</li>"
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>{COMPANY_NAME} - Financial Statement Analysis</title>
<style>
body {{ font-family: Arial, sans-serif; max-width: 800px; margin: 2em auto;
        padding: 0 1em; color: #222; }}
table {{ border-collapse: collapse; width: 100%; margin: 1em 0; }}
th, td {{ border: 1px solid #ccc; padding: 0.5em; text-align: right; }}
th:first-child, td:first-child {{ text-align: left; }}
h1 {{ font-size: 1.5em; }} h2 {{ font-size: 1.2em; margin-top: 1.5em; }}
</style>
</head>
<body>
<h1>{COMPANY_NAME}</h1>
<p>Financial Statement Analysis, {years[0]}-{years[-1]}</p>
<h2>Key ratios</h2>
<table><tr><th>Ratio</th>{''.join(f'<th>{y}</th>' for y in years)}</tr>
{rows}</table>
<h2>Notable trends</h2>
<ul>{flags_html}</ul>
<h2>Data checks</h2>
<ul>{problems_html}</ul>
<p><small>ROE, ROA, and turnover ratios use average balances where a prior
year exists. For the first year they use year end balances.</small></p>
</body>
</html>
"""


def main():
    parser = argparse.ArgumentParser(
        description="Analyze financial statements from CSV files.")
    parser.add_argument("--income", default="data/income_statement.csv",
                        help="Path to the income statement CSV.")
    parser.add_argument("--balance", default="data/balance_sheet.csv",
                        help="Path to the balance sheet CSV.")
    parser.add_argument("--out", default=None,
                        help="Write the report to a file. The extension "
                             "decides the format: .txt, .csv, or .html.")
    args = parser.parse_args()

    income_rows = load_csv(args.income)
    balance_rows = load_csv(args.balance)
    check_columns(income_rows, INCOME_COLUMNS, "Income statement")
    check_columns(balance_rows, BALANCE_COLUMNS, "Balance sheet")

    years_in = {int(r["year"]) for r in income_rows}
    years_bal = {int(r["year"]) for r in balance_rows}
    if years_in != years_bal:
        raise ValueError("Income statement and balance sheet cover "
                         "different years.")

    income = build_income(income_rows)
    balance = build_balance(balance_rows)
    ratios = compute_ratios(income, balance)
    flags = trend_flags(income, balance, ratios)
    problems = check_data_problems(income_rows, balance_rows, income, balance)

    report = build_text_report(income, balance, ratios, flags, problems)
    print(report)

    if args.out:
        out_path = Path(args.out)
        suffix = out_path.suffix.lower()
        if suffix == ".csv":
            out_path.write_text(build_csv_report(ratios))
        elif suffix == ".html":
            out_path.write_text(build_html_report(income, balance, ratios,
                                                  flags, problems))
        else:
            out_path.write_text(report + "\n")
        print(f"\nReport written to {out_path}")


if __name__ == "__main__":
    main()
