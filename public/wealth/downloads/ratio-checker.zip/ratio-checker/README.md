# Financial Statement Analyzer

A small Python tool that reads an income statement and a balance sheet from
CSV files, crunches the key ratios, and writes up what it finds in plain
English. I built it as a portfolio project to show I can take raw financial
data and turn it into something a manager can actually read.

## What it does

You give it two CSVs, one for the income statement and one for the balance
sheet, covering as many years as you want. It gives you back:

* **Ten standard ratios**, grouped the way you'd learn them in class:
  liquidity (current, quick), profitability (gross margin, net margin, ROE,
  ROA), leverage (debt to equity, debt to assets), and efficiency
  (receivables turnover, inventory turnover).
* **Trend flags in plain language.** If gross margin drops two points year
  over year, it says so and names it margin compression. Same idea for
  weakening liquidity, rising leverage, slowing collections, and inventory
  building up. The thresholds are all spelled out at the top of the code so
  nothing is magic.
* **Data checks before it trusts the numbers.** It flags negative balances
  where they make no sense, checks that assets equal liabilities plus equity
  every year, and calls out any line item that jumps more than 50% in a
  single year so you can verify it against the source documents.

The report prints to the terminal, and you can also save it as a text file,
a CSV of the ratio table, or a simple HTML page with `--out`.

## How to run it

You only need Python 3. There are no dependencies to install, nothing to
pip install, it just runs on the standard library.

```bash
cd financial-statement-analyzer
python3 analyzer.py
```

It comes with three years of sample data for a fictional company (Blue
Ridge Manufacturing Co.) in the `data/` folder, so that command works the
second you open the project.

Other options:

```bash
python3 analyzer.py --out report.html   # save a formatted HTML report
python3 analyzer.py --out ratios.csv    # save just the ratio table as CSV
python3 analyzer.py --income my_is.csv --balance my_bs.csv
```

To open it in Cursor, just open the whole `financial-statement-analyzer`
folder. The entry point is `analyzer.py`, the sample data lives in `data/`,
and the tests live in `tests/`.

To run the tests:

```bash
python3 -m unittest discover tests
```

## What the output looks like

```
Blue Ridge Manufacturing Co.
Financial Statement Analysis
Years covered: 2023-2025

KEY RATIOS
Ratio                         2023        2024        2025
----------------------------------------------------------
Current ratio                 2.27        2.12        1.95
Quick ratio                   1.25        1.12        1.00
Gross margin                 40.0%       38.0%       36.0%
Net margin                    9.4%        8.5%        6.9%
Return on equity             22.5%       21.1%       15.6%
Return on assets              11.2%       10.7%        7.7%
Debt to equity                1.00        0.96        1.07
Debt to assets                0.50        0.49        0.52
Receivables turnover          7.50        7.77        7.06
Inventory turnover            3.51        3.85        3.74

NOTABLE TRENDS
  * 2024: margin compression. Gross margin fell from 40.0% to 38.0% (down 2.0 points).
  * 2025: margin compression. Gross margin fell from 38.0% to 36.0% (down 2.0 points).

DATA CHECKS
  All checks passed: no negative balances where they should not be,
  the balance sheet balances every year, and no single line item jumped
  more than 50% year over year.
```

The sample company tells a realistic story on purpose: revenue is growing
every year, but margins are compressing and liquidity is slowly tightening.
That is exactly the kind of thing this tool is meant to surface.

## What I learned building it

A few things stuck with me. First, balance sheet ratios should use average
balances, not year end snapshots, because the balance sheet is a point in
time and the income statement covers a whole period. The code does that
whenever a prior year exists and says so in the report when it can't.

Second, I learned how easy it is for sample data to lie to you. My first
draft of the numbers didn't balance, and the script caught it immediately
because of the accounting equation check. That check exists because I needed
it myself.

Third, writing the trend flags forced me to decide what "notable" actually
means. A two point margin move matters, a half point move is noise. Picking
those cutoffs and documenting them in the code was the most accounting-like
part of the whole project. It is judgment, not just math.

## Project layout

```
financial-statement-analyzer/
  analyzer.py               # the whole tool, one file, heavily commented
  README.md                 # this file
  data/
    income_statement.csv    # 3 years of sample income statement data
    balance_sheet.csv       # 3 years of sample balance sheet data
  tests/
    test_analyzer.py        # unit tests for the ratio math and data checks
```
